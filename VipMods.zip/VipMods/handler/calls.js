const logging = require("../lib/logging");

module.exports = ({ reybot, c }) => {/*
  const call = c[0];
  if (call.status === "offer") {
    reybot.rejectCall(call.id, call.from);
  }*/
  return;
};
